# SML C 绑定 · 0.6.3

**许可**：MulanPSL-2.0（见同包 LICENSE）

**仓库**：https://gitee.com/snoware/sml

**版本**：0.6.3（对应 Rust crate `swsml` 0.6.3；C-ABI v3）

**说明**：纯 C99 自包含实现（sml.h/sml.c，零依赖）与 Rust 桥接头（sml_rs.h）二选一。

## 功能情况
- 文本 / 文件加载（含 include 展开）
- 值树遍历（类型保真：int / float / bool / str / array / object）
- 富错误（code_str / line / column / position / source / text）
- 序列化 dumps（对象 → SML 文本）
- 特性门禁 flags（沙箱）
- 版本 / 特性查询（Version / Features）
- 路径取值（get_in）
- 内存纪律（free 正确释放）

> 读路径（loads / load_file / 取值）直接遍历值树，不经 JSON；
> 仅 dumps 走官方桥 `对象 → JSON → sml_dump`。
