include "inc.sml"
a: 1
